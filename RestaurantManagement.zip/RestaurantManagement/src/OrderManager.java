import java.util.ArrayList;
import java.util.List;

public class OrderManager {
    // Static instance for Singleton
    private static OrderManager instance;

    // List to store orders
    private List<Object[]> orders;

    // Private constructor to prevent external instantiation
    private OrderManager() {
        orders = new ArrayList<>();
        // Example data (replace with real data as needed)
        orders.add(new Object[]{1, "Burger", 2, 5.99});
        orders.add(new Object[]{2, "Pizza", 1, 8.99});
        orders.add(new Object[]{3, "Pasta", 3, 7.49});
    }

    // Public method to get the Singleton instance
    public static OrderManager getInstance() {
        if (instance == null) {
            instance = new OrderManager();
        }
        return instance;
    }

    // Method to get all orders
    public List<Object[]> getOrders() {
        return orders;
    }

    // Method to remove an order by ID
    public void removeOrderById(int orderId) {
        orders.removeIf(order -> (int) order[0] == orderId);
    }

    // Method to add a new order (optional, for future use)
    public void addOrder(Object[] order) {
        orders.add(order);
    }
}
