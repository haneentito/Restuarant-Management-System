// MenuTest.java
public class MenuTest {
    public static void main(String[] args) {
        // Create a pizza with default values
        MenuItem myPizza = new Pizza();

        // Add extra cheese
        myPizza = new ExtraCheeseDecorator(myPizza);

        // Add extra sauce
        myPizza = new SauceDecorator(myPizza);

        // Add a side dish
        myPizza = new SideDecorator(myPizza);

        // Print the final description and cost
        System.out.println("Your order: " + myPizza.getDescription());
        System.out.println("Total cost: $" + myPizza.getCost());
    }
}


