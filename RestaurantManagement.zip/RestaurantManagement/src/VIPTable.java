public class VIPTable extends Table {
    @Override
    public void displayTable() {
        System.out.println("Displaying VIP Table");
    }
}

