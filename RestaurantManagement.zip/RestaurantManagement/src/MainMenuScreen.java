import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainMenuScreen {
    public MainMenuScreen(String role) {
        // Frame setup
        JFrame frame = new JFrame("Main Menu - " + role + " - Restaurant Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);

        // Background setup
        JLabel background = new JLabel();
        background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        setBackgroundImage(frame, background);

        // Main Menu Buttons
        JButton btnMenuManagement = createButton("Menu Management", 100);
        JButton btnOrderManagement = createButton("Order Management", 160);
        JButton btnStaffManagement = createButton("Staff Management", 220);
        JButton btnKitchenDisplay = createButton("Kitchen Display", 280);

        // Event listeners for button actions
        btnMenuManagement.addActionListener(e -> {
            frame.dispose();
            new MenuManagementScreen();
        });

        btnOrderManagement.addActionListener(e -> {
            frame.dispose();
            new OrderManagementScreen();
        });

        btnStaffManagement.addActionListener(e -> {
            frame.dispose();
            new StaffManagementScreen();
        });

        btnKitchenDisplay.addActionListener(e -> {
            frame.dispose();
            new KitchenDisplayScreen(new OrderSubject());  // Pass OrderSubject to initialize kitchen display
        });

        // Add buttons to background
        background.add(btnMenuManagement);
        background.add(btnOrderManagement);
        background.add(btnStaffManagement);
        background.add(btnKitchenDisplay);

        frame.add(background);
        frame.setVisible(true);
    }

    // Helper method to create buttons with common properties
    private JButton createButton(String text, int yPosition) {
        JButton button = new JButton(text);
        button.setBounds(300, yPosition, 200, 50);
        customizeButton(button);
        return button;
    }

    // Helper method to customize button style (background color, font, etc.)
    private void customizeButton(JButton button) {
        button.setBackground(new Color(128, 128, 128));  // Light gray color
        button.setForeground(Color.WHITE);  // White text
        button.setFont(new Font("Arial", Font.BOLD, 14));  // Set font style and size
        button.setFocusPainted(false);  // Remove the focus border around the button
        button.setBorder(BorderFactory.createEmptyBorder());  // Remove the default border
        button.setOpaque(true);  // Make button background solid
    }

    // Helper method to set the background image and handle resizing
    private void setBackgroundImage(JFrame frame, JLabel background) {
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ImageIcon originalIcon = new ImageIcon(getClass().getResource("/images/pexels-fotios-photos-776538.jpg"));  // Use relative path
                Image scaledImage = originalIcon.getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH);
                background.setIcon(new ImageIcon(scaledImage));
                background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
                frame.revalidate();
                frame.repaint();
            }
        });
    }

    public static void main(String[] args) {
        new MainMenuScreen("Manager");
    }
}



