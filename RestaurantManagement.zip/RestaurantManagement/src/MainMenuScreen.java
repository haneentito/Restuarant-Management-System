import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainMenuScreen {
    public MainMenuScreen(String role) {
        // Frame setup
        JFrame frame = new JFrame("Main Menu - Restaurant Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);

        // Background setup
        JLabel background = new JLabel();
        background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        setBackgroundImage(frame, background);

        // Main Menu Buttons
        JButton btnMenuManagement = new JButton("Menu Management");
        JButton btnOrderManagement = new JButton("Order Management");
        JButton btnStaffManagement = new JButton("Staff Management");
        JButton btnKitchenDisplay = new JButton("Kitchen Display");

        // Button positioning
        btnMenuManagement.setBounds(300, 100, 200, 50);
        btnOrderManagement.setBounds(300, 160, 200, 50);
        btnStaffManagement.setBounds(300, 220, 200, 50);
        btnKitchenDisplay.setBounds(300, 280, 200, 50);

        // Event listeners for button actions
        btnMenuManagement.addActionListener(e -> {
            frame.dispose();
            new MenuManagementScreen();
        });

        btnOrderManagement.addActionListener(e -> {
            frame.dispose();
            new OrderManagementScreen();
        });

        btnStaffManagement.addActionListener(e -> {
            frame.dispose();
            new StaffManagementScreen();
        });

        btnKitchenDisplay.addActionListener(e -> {
            frame.dispose();
            new KitchenDisplayScreen(new OrderSubject());  // Pass OrderSubject to initialize kitchen display
        });

        // Add buttons to background
        background.add(btnMenuManagement);
        background.add(btnOrderManagement);
        background.add(btnStaffManagement);
        background.add(btnKitchenDisplay);

        frame.add(background);
        frame.setVisible(true);
    }

    private void setBackgroundImage(JFrame frame, JLabel background) {
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ImageIcon originalIcon = new ImageIcon("C:\\Users\\tito\\OneDrive\\Pictures\\pexels-fotios-photos-776538.jpg");  // Update with your image path
                Image scaledImage = originalIcon.getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH);
                background.setIcon(new ImageIcon(scaledImage));
                background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
            }
        });
    }

    public static void main(String[] args) {
        new MainMenuScreen("Manager");
    }
}


