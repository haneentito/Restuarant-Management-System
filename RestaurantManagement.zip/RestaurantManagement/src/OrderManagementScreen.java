import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class OrderManagementScreen {
    public OrderManagementScreen() {
        JFrame frame = new JFrame("Order Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);

        // Background image
        JLabel background = new JLabel();
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ImageIcon originalIcon = new ImageIcon("C:\\Users\\tito\\OneDrive\\Pictures\\order.png");
                Image scaledImage = originalIcon.getImage().getScaledInstance(
                        frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH);
                background.setIcon(new ImageIcon(scaledImage));
                background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
            }
        });

        // Order components
        JLabel lblOrderId = new JLabel("Order ID:");
        JTextField txtOrderId = new JTextField();
        JButton btnCompleteOrder = new JButton("Complete Order");
        JButton btnToPayment = new JButton("Go to Payment Screen"); // Add new button for Payment Screen

        // Set layout and add components
        lblOrderId.setBounds(50, 50, 100, 30);
        txtOrderId.setBounds(150, 50, 200, 30);
        btnCompleteOrder.setBounds(50, 150, 200, 50);
        btnToPayment.setBounds(300, 150, 200, 50); // Position for new button

        background.setLayout(null);
        background.add(lblOrderId);
        background.add(txtOrderId);
        background.add(btnCompleteOrder);
        background.add(btnToPayment); // Add button to the background

        frame.add(background);
        frame.setVisible(true);

        // Add functionality to Complete Order button
        btnCompleteOrder.addActionListener(e -> {
            String orderId = txtOrderId.getText().trim();
            if (orderId.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter an Order ID", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                frame.dispose();
                new PaymentScreen(); // Open Payment Screen
            }
        });

        // Add functionality to Payment Screen button
        btnToPayment.addActionListener(e -> {
            frame.dispose();
            new PaymentScreen(); // Open Payment Screen directly
        });
    }

    public static void main(String[] args) {
        new OrderManagementScreen();
    }
}




