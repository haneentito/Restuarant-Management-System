import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;

public class OrderManagementScreen {
    // Static instance for Singleton
    private static OrderManagementScreen instance;

    private JFrame frame;
    private JTable orderTable;
    private DefaultTableModel tableModel;
    private OrderManager orderManager;

    // Private constructor to prevent external instantiation
    OrderManagementScreen() {
        orderManager = OrderManager.getInstance(); // Access Singleton OrderManager
        initializeUI();
    }

    private void initializeUI() {
        frame = new JFrame("Order Management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);

        // Background image
        JLabel background = new JLabel();
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ImageIcon originalIcon = new ImageIcon("C:\\Users\\tito\\OneDrive\\Pictures\\order.png");
                Image scaledImage = originalIcon.getImage().getScaledInstance(
                        frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH);
                background.setIcon(new ImageIcon(scaledImage));
                background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
            }
        });

        // Order Table
        tableModel = new DefaultTableModel(new Object[][]{}, new String[]{"Order ID", "Item Name", "Quantity", "Price"});
        orderTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(orderTable);
        scrollPane.setBounds(50, 50, 700, 300);

        // Buttons
        JButton btnCompleteOrder = new JButton("Complete Order");
        JButton btnToPayment = new JButton("Go to Payment Screen");

        // Set layout and add components
        btnCompleteOrder.setBounds(50, 400, 200, 50);
        btnToPayment.setBounds(300, 400, 200, 50);

        background.setLayout(null);
        background.add(scrollPane);
        background.add(btnCompleteOrder);
        background.add(btnToPayment);

        frame.add(background);
        frame.setVisible(true);

        // Load orders into the table
        loadOrdersToTable();

        // Add functionality to Complete Order button
        btnCompleteOrder.addActionListener(e -> completeOrder());

        // Add functionality to Payment Screen button
        btnToPayment.addActionListener(e -> {
            frame.dispose();
            PaymentScreen.getInstance(); // Open Payment Screen directly using Singleton
        });
    }

    private void loadOrdersToTable() {
        // Clear the table
        tableModel.setRowCount(0);

        // Load orders from OrderManager
        for (Object[] order : orderManager.getOrders()) {
            tableModel.addRow(order);
        }
    }

    private void completeOrder() {
        int selectedRow = orderTable.getSelectedRow();

        if (selectedRow >= 0) {
            int confirm = JOptionPane.showConfirmDialog(
                frame,
                "Mark this order as Completed and process payment?",
                "Complete Order",
                JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                // Get Order ID and Price from the table
                int orderId = (int) tableModel.getValueAt(selectedRow, 0);
                double amount = (double) tableModel.getValueAt(selectedRow, 3);

                // Process payment using PaymentManager
                PaymentManager paymentManager = PaymentManager.getInstance();
                paymentManager.processPayment(orderId, amount);

                // Remove the order from OrderManager
                orderManager.removeOrderById(orderId);

                // Refresh the table
                loadOrdersToTable();

                JOptionPane.showMessageDialog(frame, "Order completed and payment processed.");
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Please select an order to complete.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Public static method to get the Singleton instance
    public static OrderManagementScreen getInstance() {
        if (instance == null) {
            instance = new OrderManagementScreen();
        }
        return instance;
    }

    public static void main(String[] args) {
        OrderManagementScreen.getInstance(); // Access the Singleton instance
    }
}

