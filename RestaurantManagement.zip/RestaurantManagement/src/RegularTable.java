public class RegularTable extends Table {
    @Override
    public void displayTable() {
        System.out.println("Displaying Regular Table");
    }
}

