
import javax.swing.JOptionPane;

public class WalletPaymentStrategy implements PaymentStrategy {
    @Override
    public void processPayment(String amount, String paymentMethod) {
        String details = null;
        JOptionPane.showMessageDialog(null, "Payment of " + amount + " processed using Digital Wallet. Wallet Details: " + details);
    }
}
