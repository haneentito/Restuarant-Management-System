public class TestSingleton {
    public static void main(String[] args) {
        DatabaseConnection db1 = DatabaseConnection.getInstance();
        DatabaseConnection db2 = DatabaseConnection.getInstance();

        // Check if both instances are the same
        if (db1 == db2) {
            System.out.println("Singleton works! Both instances are the same.");
        } else {
            System.out.println("Singleton failed. Instances are different.");
        }
    }
}

