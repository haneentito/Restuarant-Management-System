
import javax.swing.JOptionPane;

public class CardPaymentStrategy implements PaymentStrategy {
    @Override
    public void processPayment(String amount, String paymentMethod, String details) {
        JOptionPane.showMessageDialog(null, "Payment of " + amount + " processed using Card. Card Details: " + details);
    }
}
