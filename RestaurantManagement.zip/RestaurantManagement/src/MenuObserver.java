
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

interface MenuObserver {
    void update(DefaultTableModel menuTableModel);
}

class MenuObserverRegistry {
    private static final List<MenuObserver> observers = new ArrayList<>();

    public static void registerObserver(MenuObserver observer) {
        observers.add(observer);
    }

    public static void notifyAllObservers(DefaultTableModel menuTableModel) {
        for (MenuObserver observer : observers) {
            observer.update(menuTableModel);
        }
    }
}

