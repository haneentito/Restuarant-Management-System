public interface PaymentStrategy {
    void processPayment(String amount, String paymentMethod);
}

