public class SideDecorator extends MenuItemDecorator {
    public SideDecorator(MenuItem item) {
        super(item);
    }

    @Override
    public String getDescription() {
        return decoratedItem.getDescription() + " + Side Dish";
    }

    @Override
    public double getCost() {
        return decoratedItem.getCost() + 3.00; // Additional cost for side dish
    }

    @Override
    public void displayItem() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
