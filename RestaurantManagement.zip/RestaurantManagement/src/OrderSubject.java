import java.util.ArrayList;
import java.util.List;

public class OrderSubject {
    private final List<KitchenDisplayObserver> observers = new ArrayList<>();

    // Register observer (KitchenDisplayObserver type)
    public void registerObserver(KitchenDisplayObserver observer) {
        observers.add(observer);
    }

    // Notify all registered observers about a new order
    public void notifyObservers(String order) {
        for (KitchenDisplayObserver observer : observers) {
            observer.update(order);
        }
    }

    // Add a new order and notify observers
    public void addOrder(String order) {
        notifyObservers(order);
    }
}


