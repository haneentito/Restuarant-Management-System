class MenuItemFactory {
    public static MenuItem createMenuItem(String name, String price, String category) {
        return new MenuItem(name, price, category);
    }
}

class MenuItem {
    private final String name;
    private final String price;
    private final String category;

    public MenuItem(String name, String price, String category) {
        this.name = name;
        this.price = price;
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public String getCategory() {
        return category;
    }
}




