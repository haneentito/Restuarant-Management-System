public class PaymentManager {
    private static PaymentManager instance;

    private PaymentManager() {
        // Private constructor to restrict instantiation
    }

    public static synchronized PaymentManager getInstance() {
        if (instance == null) {
            instance = new PaymentManager();
        }
        return instance;
    }

    public void processPayment(int orderId, double amount) {
        // Payment processing logic here
        System.out.println("Processing payment for Order ID: " + orderId + ", Amount: $" + amount);
    }
}

