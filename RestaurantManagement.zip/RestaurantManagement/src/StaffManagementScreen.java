import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StaffManagementScreen {
    public StaffManagementScreen() {
        // Create the frame for the Staff Management Screen
        JFrame frame = new JFrame("Staff Management Screen");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);

        // Background image for the Staff Management Screen
        JLabel background = new JLabel();
        background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        setBackgroundImage(frame, background);

        // Staff ID
        JLabel lblStaffId = new JLabel("Staff ID:");
        JTextField txtStaffId = new JTextField();

        // Staff Name
        JLabel lblStaffName = new JLabel("Staff Name:");
        JTextField txtStaffName = new JTextField();

        // Staff Role (Manager, Waiter, Chef)
        JLabel lblStaffRole = new JLabel("Staff Role:");
        String[] staffRoles = {"Manager", "Waiter", "Chef"};
        JComboBox<String> cmbStaffRole = new JComboBox<>(staffRoles);

        // Staff Salary
        JLabel lblStaffSalary = new JLabel("Staff Salary:");
        JTextField txtStaffSalary = new JTextField();

        // Buttons: Add Staff, Edit Staff, Remove Staff
        JButton btnAddStaff = createStyledButton("Add Staff", new Color(0,128,128), Color.WHITE);
        JButton btnEditStaff = createStyledButton("Edit Staff", new Color(47,79,79), Color.WHITE);
        JButton btnRemoveStaff = createStyledButton("Remove Staff", new Color(210,105,30), Color.WHITE);

        // Action listeners for buttons
        btnAddStaff.addActionListener(e -> handleAddStaff(frame, txtStaffId, txtStaffName, cmbStaffRole, txtStaffSalary));
        btnEditStaff.addActionListener(e -> handleEditStaff(frame, txtStaffId));
        btnRemoveStaff.addActionListener(e -> handleRemoveStaff(frame, txtStaffId));

        // Layout for the frame components
        arrangeComponents(background, lblStaffId, txtStaffId, lblStaffName, txtStaffName, lblStaffRole, cmbStaffRole,
                lblStaffSalary, txtStaffSalary, btnAddStaff, btnEditStaff, btnRemoveStaff);

        // Add the background to the frame
        frame.add(background);

        // Make the frame visible
        frame.setVisible(true);
    }

    // Helper method to set the background image and handle resizing
    private void setBackgroundImage(JFrame frame, JLabel background) {
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ImageIcon originalIcon = new ImageIcon("C:\\Users\\tito\\Downloads\\10306566.jpg"); // Update with the correct path
                Image scaledImage = originalIcon.getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH);
                background.setIcon(new ImageIcon(scaledImage));
                background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
            }
        });
    }

    // Helper method to create styled buttons
    private JButton createStyledButton(String text, Color bgColor, Color fgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        return button;
    }

    // Helper method to arrange components on the screen
    private void arrangeComponents(JLabel background, JLabel lblStaffId, JTextField txtStaffId, JLabel lblStaffName,
                                    JTextField txtStaffName, JLabel lblStaffRole, JComboBox<String> cmbStaffRole,
                                    JLabel lblStaffSalary, JTextField txtStaffSalary, JButton btnAddStaff,
                                    JButton btnEditStaff, JButton btnRemoveStaff) {
        background.setLayout(null); // Allow manual placement of components

        lblStaffId.setBounds(50, 50, 200, 30);
        txtStaffId.setBounds(250, 50, 200, 30);

        lblStaffName.setBounds(50, 100, 200, 30);
        txtStaffName.setBounds(250, 100, 200, 30);

        lblStaffRole.setBounds(50, 150, 200, 30);
        cmbStaffRole.setBounds(250, 150, 200, 30);

        lblStaffSalary.setBounds(50, 200, 200, 30);
        txtStaffSalary.setBounds(250, 200, 200, 30);

        btnAddStaff.setBounds(50, 300, 200, 40);
        btnEditStaff.setBounds(250, 300, 200, 40);
        btnRemoveStaff.setBounds(450, 300, 200, 40);

        // Add components to the background
        background.add(lblStaffId);
        background.add(txtStaffId);
        background.add(lblStaffName);
        background.add(txtStaffName);
        background.add(lblStaffRole);
        background.add(cmbStaffRole);
        background.add(lblStaffSalary);
        background.add(txtStaffSalary);
        background.add(btnAddStaff);
        background.add(btnEditStaff);
        background.add(btnRemoveStaff);
    }

    // Action listener method to handle Add Staff logic
    private void handleAddStaff(JFrame frame, JTextField txtStaffId, JTextField txtStaffName,
                                 JComboBox<String> cmbStaffRole, JTextField txtStaffSalary) {
        String staffId = txtStaffId.getText().trim();
        String staffName = txtStaffName.getText().trim();
        String staffRole = (String) cmbStaffRole.getSelectedItem();
        String staffSalary = txtStaffSalary.getText().trim();

        if (staffId.isEmpty() || staffName.isEmpty() || staffSalary.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(frame, "Staff added successfully!\nStaff ID: " + staffId);
    }

    // Action listener method to handle Edit Staff logic
    private void handleEditStaff(JFrame frame, JTextField txtStaffId) {
        String staffId = txtStaffId.getText().trim();
        if (staffId.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter a Staff ID to edit", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(frame, "Staff with ID " + staffId + " has been edited.");
    }

    // Action listener method to handle Remove Staff logic
    private void handleRemoveStaff(JFrame frame, JTextField txtStaffId) {
        String staffId = txtStaffId.getText().trim();
        if (staffId.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter a Staff ID to remove", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        JOptionPane.showMessageDialog(frame, "Staff with ID " + staffId + " has been removed.");
    }

    public static void main(String[] args) {
        new StaffManagementScreen();
    }
}



