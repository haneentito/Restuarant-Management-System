import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginScreen {
    public LoginScreen() {
        // Frame setup
        JFrame frame = new JFrame("Login - Restaurant Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);

        // Background label
        JLabel background = new JLabel();
        background.setBounds(0, 0, frame.getWidth(), frame.getHeight());

        // Listener for resizing background dynamically
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ImageIcon originalIcon = new ImageIcon("C:\\Users\\tito\\OneDrive\\Pictures\\pexels-fotios-photos-776538.jpg"); // Update this path to your image
                Image scaledImage = originalIcon.getImage().getScaledInstance(
                        frame.getWidth(),
                        frame.getHeight(),
                        Image.SCALE_SMOOTH);
                background.setIcon(new ImageIcon(scaledImage));
                background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
            }
        });

        // Login Panel
        JPanel loginPanel = new JPanel();
        loginPanel.setBounds(250, 150, 300, 250);
        loginPanel.setLayout(new GridLayout(4, 2, 10, 10));
        loginPanel.setOpaque(false);

        // Components
        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setForeground(Color.WHITE);

        JTextField txtUsername = new JTextField();

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setForeground(Color.WHITE);

        JPasswordField txtPassword = new JPasswordField();

        JLabel lblRole = new JLabel("Role:");
        lblRole.setForeground(Color.WHITE);

        JComboBox<String> cmbRole = new JComboBox<>(); // Hardcoded roles
        cmbRole.addItem("Manager");
        cmbRole.addItem("Chef");
        cmbRole.addItem("Waiter");

        JButton btnLogin = new JButton("Login");
        btnLogin.setBackground(new Color(150, 75, 50)); // Background color for the button
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFont(new Font("Arial", Font.BOLD, 16)); // Custom font

        // Add components to panel
        loginPanel.add(lblUsername);
        loginPanel.add(txtUsername);
        loginPanel.add(lblPassword);
        loginPanel.add(txtPassword);
        loginPanel.add(lblRole);
        loginPanel.add(cmbRole);
        loginPanel.add(new JLabel()); // Empty space
        loginPanel.add(btnLogin);

        // Add panel to the background
        background.setLayout(null);
        background.add(loginPanel);
        frame.add(background);

        // Login button action listener
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = txtUsername.getText();
                String password = new String(txtPassword.getPassword());
                String role = (String) cmbRole.getSelectedItem();

                // Simple hardcoded validation
                if (username.equals("admin") && password.equals("admin")) {  // Example credentials
                    frame.dispose(); // Close the login screen
                    new MainMenuScreen("Manager"); // Pass role as 'Manager' for testing
                } else if (username.equals("chef") && password.equals("chef")) {
                    frame.dispose();
                    new MainMenuScreen("Chef");
                } else if (username.equals("waiter") && password.equals("waiter")) {
                    frame.dispose();
                    new MainMenuScreen("Waiter");
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid credentials", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Ensure the frame is visible
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new LoginScreen(); // Show login screen
    }
}



