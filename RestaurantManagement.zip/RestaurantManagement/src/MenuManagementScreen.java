import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MenuManagementScreen {
    public MenuManagementScreen() {
        // Frame setup
        JFrame frame = new JFrame("Menu Management - Restaurant Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);

        // Background setup
        JLabel background = new JLabel();
        background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        setBackgroundImage(frame, background);

        // Menu Management Components
        JLabel lblMenuItem = new JLabel("Menu Item:");
        JTextField txtMenuItem = new JTextField();
        JLabel lblPrice = new JLabel("Price:");
        JTextField txtPrice = new JTextField();

        JButton btnAddItem = new JButton("Add Item");
        JButton btnEditItem = new JButton("Edit Item");
        JButton btnRemoveItem = new JButton("Remove Item");
        JButton btnBack = new JButton("Back to Main Menu");

        // Customize the buttons with different colors
        customizeButtonColor(btnAddItem, new Color(0,0,128));  // Light blue
        customizeButtonColor(btnEditItem, new Color(46,139,87));  // Green
        customizeButtonColor(btnRemoveItem, new Color(242, 85, 96));  // Red
        customizeButtonColor(btnBack, new Color(205,133,63));  // Orange

        // Component positioning
        lblMenuItem.setBounds(50, 50, 100, 30);
        txtMenuItem.setBounds(150, 50, 200, 30);
        lblPrice.setBounds(50, 100, 100, 30);
        txtPrice.setBounds(150, 100, 200, 30);

        btnAddItem.setBounds(50, 200, 200, 50);
        btnEditItem.setBounds(300, 200, 200, 50);
        btnRemoveItem.setBounds(550, 200, 200, 50);
        btnBack.setBounds(300, 300, 200, 50);

        // Button actions
        btnAddItem.addActionListener(e -> {
            String menuItem = txtMenuItem.getText().trim();
            String price = txtPrice.getText().trim();
            // Validate input and add item
            if (menuItem.isEmpty() || price.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // Add item logic (placeholder)
                JOptionPane.showMessageDialog(frame, "Item added successfully!");
            }
        });

        btnEditItem.addActionListener(e -> {
            // Edit item logic (placeholder)
            JOptionPane.showMessageDialog(frame, "Item edited successfully!");
        });

        btnRemoveItem.addActionListener(e -> {
            // Remove item logic (placeholder)
            JOptionPane.showMessageDialog(frame, "Item removed successfully!");
        });

        btnBack.addActionListener(e -> {
            frame.dispose();
            new MainMenuScreen("Manager");  // Navigating back to the main menu
        });

        // Add components to background
        background.add(lblMenuItem);
        background.add(txtMenuItem);
        background.add(lblPrice);
        background.add(txtPrice);
        background.add(btnAddItem);
        background.add(btnEditItem);
        background.add(btnRemoveItem);
        background.add(btnBack);

        frame.add(background);
        frame.setVisible(true);
    }

    // Helper method to set the background image and handle resizing
    private void setBackgroundImage(JFrame frame, JLabel background) {
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ImageIcon originalIcon = new ImageIcon("C:\\Users\\tito\\Downloads\\Screenshot (191).png"); // Update with your image path
                Image scaledImage = originalIcon.getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH);
                background.setIcon(new ImageIcon(scaledImage));
                background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
            }
        });
    }

    // Method to customize the button color
    private void customizeButtonColor(JButton button, Color color) {
        button.setBackground(color);  // Set the background color
        button.setForeground(Color.WHITE);  // Set the text color
        button.setFont(new Font("Arial", Font.BOLD, 14));  // Optional: Set font style and size
        button.setFocusPainted(false);  // Remove the focus border around the button
        button.setBorder(BorderFactory.createEmptyBorder());  // Remove the default border
        button.setOpaque(true);  // Make button background solid
    }

    public static void main(String[] args) {
        new MenuManagementScreen();
    }
}

