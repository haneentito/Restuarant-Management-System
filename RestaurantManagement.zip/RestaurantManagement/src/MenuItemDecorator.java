// MenuItemDecorator.java
public abstract class MenuItemDecorator extends MenuItem {
    protected MenuItem decoratedItem;

    public MenuItemDecorator(MenuItem item) {
        this.decoratedItem = item;
    }

    public String getDescription() {
        return decoratedItem.getDescription();
    }

    public double getCost() {
        return decoratedItem.getCost();
    }
}
// ExtraCheeseDecorator.java


// SauceDecorator.java

// SideDecorator.java


