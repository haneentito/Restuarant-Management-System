import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ReportsScreen {
    public ReportsScreen() {
        // Frame setup
        JFrame frame = new JFrame("Reports - Restaurant Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);

        // Background label
        JLabel background = new JLabel();
        background.setBounds(0, 0, frame.getWidth(), frame.getHeight());

        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ImageIcon originalIcon = new ImageIcon("your/image/path.jpg"); // Update with your background image path
                Image scaledImage = originalIcon.getImage().getScaledInstance(
                        frame.getWidth(),
                        frame.getHeight(),
                        Image.SCALE_SMOOTH);
                background.setIcon(new ImageIcon(scaledImage));
                background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
            }
        });

        // Components
        JLabel lblReports = new JLabel("Generate Reports");
        lblReports.setBounds(50, 20, 200, 30);
        lblReports.setFont(new Font("Arial", Font.BOLD, 16));

        JButton btnDailyReport = new JButton("Daily Report");
        JButton btnWeeklyReport = new JButton("Weekly Report");
        JButton btnMonthlyReport = new JButton("Monthly Report");
        JButton btnBack = new JButton("Back to Main Menu");

        btnDailyReport.setBounds(300, 100, 200, 50);
        btnWeeklyReport.setBounds(300, 200, 200, 50);
        btnMonthlyReport.setBounds(300, 300, 200, 50);
        btnBack.setBounds(300, 400, 200, 50);

        // Action Listeners
        btnDailyReport.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Generating Daily Report...", "Report", JOptionPane.INFORMATION_MESSAGE));
        btnWeeklyReport.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Generating Weekly Report...", "Report", JOptionPane.INFORMATION_MESSAGE));
        btnMonthlyReport.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Generating Monthly Report...", "Report", JOptionPane.INFORMATION_MESSAGE));
        btnBack.addActionListener(e -> {
            frame.dispose();
            new MainMenuScreen("Manager");
        });

        // Add components to background
        background.setLayout(null);
        background.add(lblReports);
        background.add(btnDailyReport);
        background.add(btnWeeklyReport);
        background.add(btnMonthlyReport);
        background.add(btnBack);

        frame.add(background);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new ReportsScreen(); // Test independently
    }
}

