public class TableFactory {
    public static Table createTable(String type) {
        switch (type) {
            case "Regular":
                return new RegularTable();
            case "VIP":
                return new VIPTable();
            case "Outdoor":
                return new OutdoorTable();
            default:
                throw new IllegalArgumentException("Unknown Table type");
        }
    }
}

