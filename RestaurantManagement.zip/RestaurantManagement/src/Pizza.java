// Pizza.java
public class Pizza extends MenuItem {
    private String name;
    private double price;

    // Default constructor with default values
    public Pizza() {
        this.name = "Pizza"; // Default name
        this.price = 8.00;    // Default price
    }

    public String getDescription() {
        return name;  // Return the name of the pizza
    }

    public double getCost() {
        return price;  // Return the cost of the pizza
    }
}

