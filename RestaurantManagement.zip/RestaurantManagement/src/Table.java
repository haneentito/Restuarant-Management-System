public abstract class Table {
    public abstract void displayTable();
}



