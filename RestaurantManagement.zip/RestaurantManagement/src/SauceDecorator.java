public class SauceDecorator extends MenuItemDecorator {
    public SauceDecorator(MenuItem item) {
        super(item);
    }

    @Override
    public String getDescription() {
        return decoratedItem.getDescription() + " + Extra Sauce";
    }

    @Override
    public double getCost() {
        return decoratedItem.getCost() + 1.50; // Additional cost for extra sauce
    }

    @Override
    public void displayItem() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

