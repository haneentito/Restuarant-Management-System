public class Dessert extends MenuItem {
    public Dessert(String name, String price) {
        super(name, price);
    }

    public void displayItem() {
        System.out.println("Dessert: " + getName() + ", Price: " + getPrice());
    }

    public String getName() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getPrice() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

