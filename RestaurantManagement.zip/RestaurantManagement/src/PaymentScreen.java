import java.awt.Color;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.*;

public class PaymentScreen {
    private static PaymentScreen instance; // Singleton instance
    private PaymentStrategy paymentStrategy;

    private PaymentScreen() {
        initializeUI();
    }

    // Singleton getInstance method
    public static PaymentScreen getInstance() {
        if (instance == null) {
            instance = new PaymentScreen();
        }
        return instance;
    }

    private void initializeUI() {
        // Create the frame for the Payment Screen
        JFrame frame = new JFrame("Payment Screen");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);

        // Background image for the Payment Screen
        JLabel background = new JLabel();
        background.setBounds(0, 0, frame.getWidth(), frame.getHeight());

        // Add background resizing logic
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ImageIcon originalIcon = new ImageIcon("C:\\Users\\tito\\OneDrive\\Pictures\\copy-space-with-cards-cart.jpg"); // Update with correct path
                if (originalIcon.getImageLoadStatus() != MediaTracker.COMPLETE) {
                    JOptionPane.showMessageDialog(frame, "Background image not found", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    Image scaledImage = originalIcon.getImage().getScaledInstance(
                            frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH);
                    background.setIcon(new ImageIcon(scaledImage));
                }
                background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
            }
        });

        // Payment Amount
        JLabel lblPaymentAmount = new JLabel("Payment Amount:");
        JTextField txtPaymentAmount = new JTextField();

        // Payment Method Dropdown
        JLabel lblPaymentMethod = new JLabel("Payment Method:");
        String[] paymentMethods = {"Cash", "Card", "Digital Wallet"};
        JComboBox<String> cmbPaymentMethod = new JComboBox<>(paymentMethods);

        // Card Details (only for card payment method)
        JLabel lblCardDetails = new JLabel("Card Details:");
        JTextField txtCardDetails = new JTextField();
        lblCardDetails.setEnabled(false); // Disabled initially
        txtCardDetails.setEnabled(false); // Disabled initially

        // Digital Wallet Details (only for digital wallet payment method)
        JLabel lblWalletDetails = new JLabel("Wallet Email/Phone:");
        JTextField txtWalletDetails = new JTextField();
        lblWalletDetails.setEnabled(false); // Disabled initially
        txtWalletDetails.setEnabled(false); // Disabled initially

        // Process Payment Button
        JButton btnProcessPayment = new JButton("Process Payment");
        JButton btnCancel = new JButton("Cancel");

        // Customize button colors
        btnProcessPayment.setBackground(new Color(0, 0, 128));
        btnProcessPayment.setForeground(Color.WHITE);
        btnCancel.setBackground(new Color(128, 0, 0));
        btnCancel.setForeground(Color.WHITE);

        // Action listeners for payment method dropdown
        cmbPaymentMethod.addActionListener(e -> {
            String selectedMethod = (String) cmbPaymentMethod.getSelectedItem();
            switch (selectedMethod) {
                case "Card":
                    lblCardDetails.setEnabled(true);
                    txtCardDetails.setEnabled(true);
                    lblWalletDetails.setEnabled(false);
                    txtWalletDetails.setEnabled(false);
                    break;
                case "Digital Wallet":
                    lblCardDetails.setEnabled(false);
                    txtCardDetails.setEnabled(false);
                    lblWalletDetails.setEnabled(true);
                    txtWalletDetails.setEnabled(true);
                    break;
                default:
                    lblCardDetails.setEnabled(false);
                    txtCardDetails.setEnabled(false);
                    lblWalletDetails.setEnabled(false);
                    txtWalletDetails.setEnabled(false);
            }
        });

        // Action listener for processing payment
        btnProcessPayment.addActionListener(e -> {
            String amountText = txtPaymentAmount.getText().trim();
            String paymentMethod = (String) cmbPaymentMethod.getSelectedItem();
            String cardDetails = txtCardDetails.getText().trim();
            String walletDetails = txtWalletDetails.getText().trim();

            // Validate payment amount
            if (amountText.isEmpty() || !amountText.matches("\\d+(\\.\\d{1,2})?")) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid payment amount", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Set the payment strategy based on the selected payment method
            if (paymentMethod.equals("Card")) {
                paymentStrategy = new CardPaymentStrategy();
            } else if (paymentMethod.equals("Digital Wallet")) {
                paymentStrategy = new WalletPaymentStrategy();
            } else {
                paymentStrategy = new CashPaymentStrategy();
            }

            // Process the payment using the selected strategy
            paymentStrategy.processPayment(amountText, cardDetails.isEmpty() ? walletDetails : cardDetails);
        });

        // Action listener for canceling the payment
        btnCancel.addActionListener(e -> frame.dispose());

        // Layout for the frame components
        background.setLayout(null);
        lblPaymentAmount.setBounds(50, 50, 200, 30);
        txtPaymentAmount.setBounds(250, 50, 200, 30);

        lblPaymentMethod.setBounds(50, 100, 200, 30);
        cmbPaymentMethod.setBounds(250, 100, 200, 30);

        lblCardDetails.setBounds(50, 150, 200, 30);
        txtCardDetails.setBounds(250, 150, 200, 30);

        lblWalletDetails.setBounds(50, 200, 200, 30);
        txtWalletDetails.setBounds(250, 200, 200, 30);

        btnProcessPayment.setBounds(50, 300, 200, 40);
        btnCancel.setBounds(250, 300, 200, 40);

        // Add components to the background
        background.add(lblPaymentAmount);
        background.add(txtPaymentAmount);
        background.add(lblPaymentMethod);
        background.add(cmbPaymentMethod);
        background.add(lblCardDetails);
        background.add(txtCardDetails);
        background.add(lblWalletDetails);
        background.add(txtWalletDetails);
        background.add(btnProcessPayment);
        background.add(btnCancel);

        // Add the background to the frame
        frame.add(background);

        // Make the frame visible
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        PaymentScreen.getInstance();
    }
}

