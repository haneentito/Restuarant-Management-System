import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class KitchenDisplayScreen extends KitchenDisplayObserver {
    private final DefaultListModel<String> kitchenOrdersModel = new DefaultListModel<>();

    public KitchenDisplayScreen(OrderSubject orderSubject) {
        // Register this screen as an observer of the order subject
        orderSubject.registerObserver(this);

        // Frame setup
        JFrame frame = new JFrame("Kitchen Display - Restaurant Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);

        // Background label
        JLabel background = new JLabel();
        background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
        setBackgroundImage(frame, background);  // Set the background image

        // Components
        JLabel lblKitchenOrders = new JLabel("Kitchen Orders");
        lblKitchenOrders.setBounds(50, 20, 200, 30);
        customizeLabel(lblKitchenOrders);

        JList<String> kitchenOrdersList = new JList<>(kitchenOrdersModel);
        JScrollPane kitchenScrollPane = new JScrollPane(kitchenOrdersList);
        kitchenScrollPane.setBounds(50, 70, 700, 400);

        // Customized Buttons
        JButton btnBack = new JButton("Back to Main Menu");
        customizeButton(btnBack, new Color(128, 128, 128), Color.WHITE);  // Custom button style
        btnBack.setBounds(300, 500, 200, 50);

        // Action Listener for the back button
        btnBack.addActionListener(e -> {
            frame.dispose();
            new MainMenuScreen("Chef");  // Navigate back to the main menu
        });

        // Add components to background
        background.setLayout(null);
        background.add(lblKitchenOrders);
        background.add(kitchenScrollPane);
        background.add(btnBack);

        frame.add(background);
        frame.setVisible(true);
    }

    // Helper method to set the background image and handle resizing
    private void setBackgroundImage(JFrame frame, JLabel background) {
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                ImageIcon originalIcon = new ImageIcon(getClass().getResource("/images/nice-wood-kitchen.jpg")); // Relative path to the background image
                Image scaledImage = originalIcon.getImage().getScaledInstance(frame.getWidth(), frame.getHeight(), Image.SCALE_SMOOTH);
                background.setIcon(new ImageIcon(scaledImage));
                background.setBounds(0, 0, frame.getWidth(), frame.getHeight());
            }
        });
    }

    // Customize label style
    private void customizeLabel(JLabel label) {
        label.setFont(new Font("Arial", Font.BOLD, 16));
        label.setForeground(Color.WHITE);
    }

    // Customize button style (background color, font, etc.)
    private void customizeButton(JButton button, Color bgColor, Color textColor) {
        button.setBackground(bgColor);
        button.setForeground(textColor);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder());
        button.setOpaque(true);
    }

    // Update the kitchen display with the new order
    public void update(String order) {
        // Update the UI with the new order status
        SwingUtilities.invokeLater(() -> kitchenOrdersModel.addElement(order));
    }

    public static void main(String[] args) {
        // Assuming OrderSubject is implemented elsewhere
        OrderSubject orderSubject = new OrderSubject();  // This will hold and notify orders
        new KitchenDisplayScreen(orderSubject);  // Initialize the screen
    }
}
