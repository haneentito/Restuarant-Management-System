
import java.util.ArrayList;
import java.util.List;

public class MenuItemModel {
    private List<MenuItem> menuItems;

    public MenuItemModel() {
        menuItems = new ArrayList<>();
    }

    public void addMenuItem(MenuItem item) {
        menuItems.add(item);
    }

    public List<MenuItem> getMenuItems() {
        return menuItems;
    }
}
