public class OutdoorTable extends Table {
    @Override
    public void displayTable() {
        System.out.println("Displaying Outdoor Table");
    }
}

