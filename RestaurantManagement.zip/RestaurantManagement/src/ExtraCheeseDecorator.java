public class ExtraCheeseDecorator extends MenuItemDecorator {
    public ExtraCheeseDecorator(MenuItem item) {
        super(item);
    }

    @Override
    public String getDescription() {
        return decoratedItem.getDescription() + " + Extra Cheese";
    }

    @Override
    public double getCost() {
        return decoratedItem.getCost() + 2.00; // Additional cost for extra cheese
    }

    public void displayItem() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
